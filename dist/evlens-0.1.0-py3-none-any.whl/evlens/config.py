LOGGER_NAME = "evlens"
LOGGER_FORMAT = '%(asctime)s: %(levelname)s (%(name)s:L%(lineno)d) - %(message)s'
DATETIME_FORMAT = "%Y-%m-%d_T%H_%M_%S%Z"
